package com.scm.scm20.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageController {
    //HOME
    @RequestMapping("/home")
    public String homepage(){
        System.out.println("Home page handler");
        return "home";
    }

    //ABOUT
    @RequestMapping("/about")
    public String aboutPage(){
        System.out.println("About page loading");
        return "about";
    }

    //SERVICES
    @RequestMapping("/services")
    public String servicepage(){
        System.out.println("services page loading");
        return "services";
    }

    //CONTACT
    @RequestMapping("/contact")
    public String contactPage(){
        System.out.println("Contact page loading");
        return "contact";
    }

    //LOGIN
    @RequestMapping("/login")
    public String loginPage(){
        System.out.println("Login page loading");
        return "login";
    }

    //SIGNUP
    @RequestMapping("/register")
    public String signupPage(){
        System.out.println("Signup page loading");
        return "register";
    }
}
