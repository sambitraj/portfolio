package com.scm.scm20.entities;

public enum Providers {
    SELF, GOOGLE, GITHUB
}
